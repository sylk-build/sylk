from setuptools import setup, find_packages

setup(
    extras_require={
        "docs": ["sylk-docs"],
    }
)
