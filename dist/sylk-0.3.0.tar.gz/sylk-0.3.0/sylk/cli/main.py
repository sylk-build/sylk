# Copyright (c) 2023 sylk.build

# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files (the
# "Software"), to deal in the Software without restriction, including
# without limitation the rights to use, copy, modify, merge, publish,
# distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so, subject to
# the following conditions:

# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
# LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
# WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
from datetime import datetime
from importlib import reload
import logging
import argparse
import os
from platform import platform
import subprocess
from sys import flags
from inquirer import errors
import re
from sylk import __version__, config
from sylk.architect import SylkArchitect
from sylk.cli import theme, prompter
from sylk.commons import (
    helpers,
    file_system,
    errors,
    resources,
    parser,
    config as prj_conf,
    protos,
)
from sylk.commons.pretty import (
    print_info,
    print_note,
    print_version,
    print_success,
    print_warning,
    print_error,
)
from sylk.commons.protos.sylk.SylkField.v1 import SylkField_pb2
from sylk.cli.commands import (
    call,
    extend,
    migrate,
    new,
    build,
    generate,
    ls,
    package as pack,
    run,
    edit,
    template,
    config as config_command,
    cloud,
    plugin,
)
from pathlib import Path

_TEMPLATES = config.configs.sylk_templates
# _TEMPLATES = []
# templates_dir = os.path.dirname(os.path.dirname(__file__))+'/commons/templates'
# for d in file_system.walkDirs(templates_dir):
#     if d != templates_dir:
#         for f in file_system.walkFiles(d):
#             domain = d.split('/')[-1]
#             template_name = f.split('.')[0]
#             _TEMPLATES.append(f'@{domain}/{template_name}')


def field_exists_validation(new_field, fields, msg):
    if new_field in fields:
        raise errors.SylkProtoError(
            "Message", f"Field {new_field} already exits under {msg}"
        )
    return True


def enum_value_validate(answers, current):
    try:
        int(current)
    except Exception:
        raise errors.SylkValidationError(
            current, reason="Enum Value MUST be an integer value"
        )
    return True


def validation(answers, current):
    if len(current) == 0:
        raise prompter.inquirer_errors.ValidationError(
            current, reason="Resource name must not be blank"
        )
    if len(re.findall("\s", current)) > 0:
        raise prompter.inquirer_errors.ValidationError(
            current, reason="Resource name must not include blank spaces"
        )
    if len(re.findall("-", current)) > 0:
        raise prompter.inquirer_errors.ValidationError(
            current,
            reason="Resource name must not include hyphens, underscores are allowed",
        )
    regex = re.compile("[@_!#$%^&*()<>?/\|}{~:]")
    if regex.search(current) != None:
        raise prompter.inquirer_errors.ValidationError(
            current, reason="Resource name must not include special charcters"
        )

    return True


log = logging.getLogger(__name__)
well_known_type = helpers._WellKnowns

fields_opt = [
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_DOUBLE),
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_FLOAT),
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_INT64),
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_INT32),
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_BOOL),
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_STRING),
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_MESSAGE),
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_BYTES),
    SylkField_pb2.SylkFieldTypes.Name(SylkField_pb2.TYPE_ENUM),
]
field_label = [
    SylkField_pb2.SylkFieldLabels.Name(SylkField_pb2.LABEL_OPTIONAL),
    SylkField_pb2.SylkFieldLabels.Name(SylkField_pb2.LABEL_REPEATED),
]

sylk_g_s_q = [
    prompter.QText(name="service", message="Enter service name", validate=validation)
]
sylk_g_e_q = [
    prompter.QText(name="enum", message="Enter enum name", validate=validation)
]


DEFAULT_PORT = 44880


def main(args=None):
    # Print sylk 'Logo'
    print(theme.logo_ascii_art_color)
    # If first run of CLI ask for analytic usage
    if config.configs.first_run:
        confirm_analytics = prompter.QConfirm(
            name="analytic",
            message="We want to gather some basic usage and bug report while you are using sylk.build CLI",
            color="warning",
            default=True,
        )
        analytic = prompter.ask_user_question(questions=[confirm_analytics])
        p = Path(__file__).parents[1]
        hash_token = platform() + ":" + datetime.today().isoformat()

        config_file = "".join(file_system.rFile(file_system.join_path(p, "config.py")))
        config_file = config_file.replace('token=""', 'token="{}"'.format(hash_token))
        file_system.wFile(
            file_system.join_path(p, "config.py"), content=config_file, overwrite=True
        )

        if analytic is None or analytic.get("analytic") == False:
            reload(config)
            # helpers.send_analytic_event({'DisabledAnalytic':hash_token})
            config_file = config_file.replace("analytics=True", "analytics=False")
        else:
            config_file = config_file.replace("analytics=False", "analytics=True")
        config_file = config_file.replace("first_run=True", "first_run=False")
        file_system.wFile(
            file_system.join_path(p, "config.py"), content=config_file, overwrite=True
        )

    """
    Main CLI processing, with argpars package.
    """
    # Main cli parser
    parser = argparse.ArgumentParser(
        prog="sylk",
        description="Command line interface for the sylk.build package build awesome gRPC micro-services. For more information please visit https://www.sylk.build there you can find additional documentation and tutorials.",
        epilog=f"For more information see - https://docs.sylk.build | Created with love by Amit Shmulevitch. 2022 © sylk.build [{__version__.__version__}]",
    )

    # parser.add_argument('test', help='test')
    # Instantiating sub parsers object
    subparsers = parser.add_subparsers(
        dest="command", title="command", help="Main modules to interact with sylk CLI."
    )
    # subparsers.required = True

    """Cloud commands"""
    parser_login = subparsers.add_parser(
        "login", help="Login to sylk cloud organziation"
    )
    parser_login.add_argument("organization", help="Set the login by organization id")

    parser_cloud = subparsers.add_parser(
        "registry", help="Interact with sylk's cloud API"
    )
    parser_cloud.add_argument(
        "project_id",
        help="Set you sylk cli to default organization via personal access token",
    )
    group_cloud = parser_cloud.add_argument_group("Projects")
    group_cloud.add_argument(
        "action",
        help="Pull / Push / Build a sylk project",
        default="pull",
        choices=["pull", "push", "build"],
    )
    # group_cloud.add_argument('push', help='Set you sylk cli to default organization via personal access token')

    """New command"""
    parser_new = subparsers.add_parser("new", help="Create new project")
    parser_new.add_argument("project", help="Project name")
    parser_new.add_argument(
        "-p", "--path", required=False, help="Path for the project root directory"
    )
    parser_new.add_argument(
        "--port", default=DEFAULT_PORT, required=False, help="Port server will run on"
    )
    parser_new.add_argument(
        "--host", default="localhost", required=False, help="Host name for server"
    )
    parser_new.add_argument("--domain", required=False, help="Project domain")
    parser_new.add_argument("-s", "--server", required=False, help="Server language")
    parser_new.add_argument(
        "-c",
        "--clients",
        nargs="*",
        required=False,
        help="Clients language list seprated by spaces",
    )
    parser_new.add_argument(
        "--template",
        default=_TEMPLATES[0] if len(_TEMPLATES) > 0 else None,
        required=False,
        help="Create new project based on template",
    )
    parser_new.add_argument(
        "--project-id",
        default=None,
        required=False,
        help="The project id from sylk.build cloud platform",
    )
    parser_new.add_argument(
        "--token",
        default=None,
        required=False,
        help="The access token for sylk platform needed if used with --project-id",
    )
    parser_new.add_argument(
        "--base-protos", default="protos", required=False, help="The base sub-directory under root project which will hold all protobuf files"
    )
    parser_new.add_argument(
        "--format", default="json", required=False, choices=['json','textpb'], help="The sylk local schema format, for large schemas it is recommended to save the schema into protobuf with 'textpb' option"
    )

    parser_n = subparsers.add_parser("n", help="A shortand for new commands")
    parser_n.add_argument("project", help="Project name")
    parser_n.add_argument(
        "-p", "--path", required=False, help="Path for the project root directory"
    )
    parser_n.add_argument(
        "--port", default=DEFAULT_PORT, required=False, help="Port server will run on"
    )
    parser_n.add_argument(
        "--host", default="localhost", required=False, help="Host name for server"
    )
    parser_n.add_argument("--domain", required=False, help="Project domain")
    parser_n.add_argument("-s", "--server", required=False, help="Server language")
    parser_n.add_argument(
        "-c",
        "--clients",
        nargs="*",
        required=False,
        help="Clients language list seprated by spaces",
    )
    parser_n.add_argument(
        "--template",
        choices=_TEMPLATES,
        default=_TEMPLATES[0] if len(_TEMPLATES) > 0 else None,
        required=False,
        help="Create new project based on template",
    )
    parser_n.add_argument(
        "--project-id",
        default=None,
        required=False,
        help="The project id from sylk.build cloud platform",
    )
    parser_n.add_argument(
        "--token",
        default=None,
        required=False,
        help="The access token for sylk platform needed if used with --project-id",
    )
    parser_n.add_argument(
        "--base-protos", default="protos", required=False, help="The base sub-directory under root project which will hold all protobuf files"
    )
    parser_n.add_argument(
        "--format", default="json", required=False, choices=['json','textpb'], help="The sylk local schema format, for large schemas it is recommended to save the schema into protobuf with 'textpb' option"
    )

    """Generate command"""

    parser_generate = subparsers.add_parser(
        "generate", help="Generate resources commands"
    )
    parser_generate.add_argument(
        "resource",
        choices=["service", "package", "message", "rpc", "enum"],
        help="Generate a sylk.build resource from specific resource type",
    )
    parser_generate.add_argument(
        "name",
        help="The resource path for ex' google/protobuf/Timestamp to create 'Timestamp' message under 'google.protobuf' package. note that the path can be filesystem like or proto path with '.' seperating the namespaces.",
    )
    # parser_generate.add_argument("-n", "--name", help="Name for the resource")
    parser_generate.add_argument("-p", "--parent", help="Name for the parent resource if creating an 'inline' resource")
    parser_generate.add_argument(
        "-d",
        "--deps",nargs='*', default=[],required=False, help="The resource dependencies"
    )
    parser_generate.add_argument(
        "-t",
        "--tag", default=None,required=False, help="The filename to host the protobuf resource"
    )
    parser_generate.add_argument(
        "--build", action="store_true", required=False, help="Auto build resources"
    )

    parser_g = subparsers.add_parser("g", help="A shortand for generate commands")
    parser_g.add_argument(
        "resource",
        choices=["s", "p", "m", "r", "e"],
        help='Generate a sylk.build resource from specific resource type, for e.x "s" stands for "service"',
    )
    parser_g.add_argument(
        "name",
        help="The resource path for ex' google/protobuf/Timestamp to create 'Timestamp' message under 'google.protobuf' package. note that the path can be filesystem like or proto path with '.' seperating the namespaces.",
    )
    # parser_g.add_argument("-n", "--name", help="Name for the resource")
    parser_g.add_argument("-p", "--parent", help="Name for the parent resource if creating an 'inline' resource")
    parser_g.add_argument(
        "-d",
        "--deps", nargs='*',default=[], required=False, help="The resource dependencies"
    )
    parser_g.add_argument(
        "-t",
        "--tag", default=None,required=False, help="The filename to host the protobuf resource"
    )
    parser_g.add_argument(
        "--build", action="store_true", required=False, help="Auto build resources"
    )

    """List command"""

    parser_list = subparsers.add_parser("ls", help="List resources commands")

    parser_list.add_argument(
        "--full-name",
        metavar="fullName",
        required=False,
        help='Display a resource report for specific resoource by passing in a full name, for e.x domain.test.GetTest will return "GetTest" (RPC) which under "test" (service)',
    )
    parser_list.add_argument(
        "-t",
        "--type",
        choices=["service", "package", "message", "rpc", "enum", "extension"],
        help="List a sylk.build resource from specific resource type",
    )
    parser_list.add_argument(
        "-d",
        "--dependencies",
        action="store_true",
        help="List the dependencies graph for your project",
    )
    parser_list.add_argument(
        "-c",
        "--cloud",
        action="store_true",
        help="List the cloud project for your sylk.build account",
    )
    parser_list.add_argument(
        "--templates", action="store_true", help="List all available templates"
    )

    """Package command"""

    parser_pkg = subparsers.add_parser(
        "package", help="Attach a package into other services / package"
    )
    parser_pkg.add_argument("source", help="Package full name")
    parser_pkg.add_argument("target", help="Package path or service name")
    parser_pkg.add_argument(
        "-r", "--remove", action="store_true", help="Package path or service name"
    )

    """Edit command"""

    parser_edit = subparsers.add_parser("edit", help="Edit any sylk.build resource")
    parser_edit.add_argument("name", help="Resource full name")
    parser_edit.add_argument(
        "-a",
        "--action",
        choices=["add", "remove", "modify"],
        help="Choose which action to preform on resource",
    )
    parser_edit.add_argument(
        "--sub-actions",
        nargs="*",
        help="Choose which sub-action to preform on resource",
    )

    """Template command"""
    parser_template = subparsers.add_parser(
        "template",
        help="Create a template from your sylk.json / proto files directory / sylk.template.py",
    )
    parser_template.add_argument(
        "path", help="Path for sylk.json / protos files directory / sylk.template.py"
    )
    parser_template.add_argument(
        "-c",
        "--code",
        action="store_true",
        help="Create a template including code files",
    )
    parser_template.add_argument(
        "--out-path",
        help="Specify the template file location, defaulted to root project dir",
    )
    parser_template.add_argument(
        "--template-name",
        help="Specify the template name, defaulted to project package name",
    )
    parser_template.add_argument(
        "--load", action="store_true", help="Initalize a template"
    )

    """Build command"""
    parser_build = subparsers.add_parser("build", help="Build project resources")
    parser_build.add_argument(
        "--protos", action="store_true", help="Build resources protos files only"
    )
    parser_build.add_argument(
        "--code", action="store_true", help="Build resources code classes files only"
    )

    """Call command"""
    parser_call = subparsers.add_parser("call", help="Call a RPC")
    parser_call.add_argument("service", help="Service full path")
    parser_call.add_argument("rpc", help="RPC name")
    parser_call.add_argument(
        "--debug", action="store_true", help="Debug the call process"
    )
    parser_call.add_argument(
        "--host", default="localhost", help="Pass a host of service"
    )
    parser_call.add_argument(
        "--port", default=DEFAULT_PORT, help="Pass a port for service"
    )
    parser_call.add_argument(
        "--timeout",
        default=10,
        help="An optional duration of time in seconds to allow for the RPC",
    )

    """Extend command"""

    parser_extend = subparsers.add_parser(
        "extend", help="Extend any sylk.build resource"
    )
    parser_extend.add_argument("name", help="Resource full name")
    parser_extend.add_argument("--extension", help="Extension full name")

    """Run server"""
    parser_run_server = subparsers.add_parser(
        "run", help="Run server on current active project"
    )
    parser_run_server.add_argument(
        "--log-level",
        choices=['debug','info'],
        help="Start the gRPC server with debug mode attached",
    )

    """Migrate command"""
    praser_migrate = subparsers.add_parser(
        "migrate", help="Migrate existing gRPC project to sylk.build project"
    )
    praser_migrate.add_argument("protos", help="Relative path of proto directory")
    praser_migrate.add_argument(
        "--format", choices=["json", "python"], help="Relative path of proto directory"
    )
    praser_migrate.add_argument(
        "--server-language",
        default="python",
        choices=["python", "typescript"],
        help="Chose a server language for migration",
    )
    praser_migrate.add_argument(
        "--clients",
        nargs="*",
        default=["python"],
        choices=["python", "typescript"],
        help="Enter one or more clients",
    )

    """Configs command"""
    parse_configs = subparsers.add_parser(
        "configs", help="Display sylk.build Configurations"
    )
    parse_configs.add_argument(
        "--edit", action="store_true", help="Edit configurations"
    )
    parse_configs.add_argument(
        "--dict",
        action="store_true",
        default=False,
        help="Display all configs of of current project in dictionary mode",
    )
    parse_configs.add_argument(
        "--token",
        action="store_true",
        help="Refresh 'Personal Access Token' with new one",
    )

    """Plugins command"""
    parser_plugin = subparsers.add_parser("plugin", help="Sylk plugin command")
    plugin_subparser = parser_plugin.add_subparsers(dest="action")

    run_plugin_parser = plugin_subparser.add_parser("run")
    run_plugin_parser.add_argument(
        "plugin",
        nargs="*",
        metavar="plugin-name",
        help="The executable path for protoc plugin",
    )
    run_plugin_parser.add_argument(
        "--protos", nargs="*", help="List of proto files relative to current directory"
    )
    run_plugin_parser.add_argument(
        "-d",
        "--dir",
        help="The plugin base directory, if not specified it will lookup sylk base plugins",
    )
    run_plugin_parser.add_argument(
        "--out-dir",
        default=".",
        help="The plugin output directory",
    )
    run_plugin_parser.add_argument(
        "--opt",
        default="",
        help="The plugin options, in a text format e.g: some_key=somevalue,some_other_key=2",
    )
    run_plugin_parser.add_argument(
        "-I",
        nargs='*',
        default=[],
        help="Include directories",
    )


    # Utils
    parser.add_argument(
        "-v",
        "--version",
        action="store_true",
        help="Display sylk.build current installed version",
    )

    parser.add_argument(
        "-e",
        "--expand",
        action="store_true",
        help="Expand optional fields for each resource",
    )

    # Log level optional argument
    parser.add_argument(
        "--loglevel",
        default="ERROR",
        help="Log level",
        choices=[
            "DEBUG",
            "INFO",
            "WARNING",
            "ERROR",
            "CRITICAL",
        ],
    )

    parser.add_argument(
        "--verbose", action="store_true", help="Control on verbose logging"
    )

    parser.add_argument(
        "-u", "--undo", action="store_true", help="Undo last sylk.json modification"
    )
    parser.add_argument(
        "-r",
        "--redo",
        action="store_true",
        help="Redo sylk.json modification, if undo has been made.",
    )

    parser.add_argument(
        "--purge", action="store_true", help="Purge .sylk/contxt.json file"
    )
    # Parse all command line arguments
    args = parser.parse_args(args)

    # New sub-parsers
    if hasattr(args, "command"):
        if args.command == "plugin":
            if args.action == "run":
                plugin.run(args)
            else:
                print_error(
                    "Action '{0}' is not supported yet on {1}".format(
                        args.action, args.command
                    )
                )

    log.setLevel(args.loglevel)
    log.debug(args)

    if config.configs.analytics:
        helpers.send_analytic_event(args)

    if args.verbose:
        print_note(args, True, "Argument passed to sylk CLI")

    if hasattr(args, "project"):
        """New command process"""
        sylk_project_config = prj_conf.parse_project_config(os.getcwd(),proto=True)
        # print_info(args,True)
        new.create_new_project(
            args.project,
            args.path,
            args.host,
            args.port,
            args.server,
            args.clients,
            domain=args.domain,
            template=args.template,
            project_id=args.project_id,
            configs=sylk_project_config,
            base_proto_path=args.base_protos,
            format=args.format,
            token=args.token
        )
        exit(0)
    else:
        if helpers.check_if_under_project():
            sylk_project_config = prj_conf.parse_project_config(os.getcwd())
            # print_info(sylk_project_config,True)
            sylk_json_path = file_system.join_path(os.getcwd(), "sylk.json")
            sylk_format = sylk_project_config.get('format','json')
            try:
                SYLK_JSON = file_system.rFile(sylk_json_path, json=True, flags='rb' if sylk_format == 'json' else 'r')
                SYLK_JSON = helpers.SylkJson(sylk_json=SYLK_JSON)
            except Exception as e:
                print_error("Error - sylk.json file is not valid !")
                print_error(e)
                exit(1)

            if args.expand:
                print_note("Creating resource in expanded mode")

            if args.verbose:
                print_note(SYLK_JSON._sylk_json, True, "sylk.json")

            """Cloud commands"""
            if hasattr(args, "project_id"):
                sylkCloud = cloud.SylkCloud(
                    token=sylk_project_config.get("token"), SylkJson=SYLK_JSON
                )
                if args.action == "build":
                    sylkCloud.buildProject()
                elif args.action == "pull":
                    sylkCloud.pull_project(project_id=args.project_id, overwrite=True)
                else:
                    print_error(
                        "Pushing local project to registry is not supported yet."
                    )
                    exit(1)

            elif hasattr(args, "organization"):
                sylk_project_config = prj_conf.parse_project_config(os.getcwd())
                # print_note(sylk_project_config,True)
                print_info(f'Logging into "{args.organization}"')
                cloud.SylkCloud(
                    sylk_project_config.get("token"), args.organization, None
                )
                print_success(f'Logged into: "{args.organization}"')

            elif hasattr(args, "resource"):
                """Generate command process"""

                # Small validations:
                # Project name
                if SYLK_JSON.project.get("name") is None:
                    print_warning("Project name value is not specified !")
                # Project domain
                if SYLK_JSON.domain is None:
                    print_warning("Project domain value is not specified !")

                namespace = parse_namespace_resource(
                    args.resource, args.name, SYLK_JSON
                )
                
                resource_name = f" [{args.name}]" if args.name is not None else ""

                print_info(f"Generating new resource '{namespace[0]}'{resource_name}")
                results = prompter.ask_user_question(
                    questions=namespace[1] if args.name is None else namespace[1][1:]
                )
                if results is None:
                    print_error("Must answer all questions")
                    exit(1)
                elif args.name is not None:
                    results[namespace[0]] = args.name
                ARCHITECT = SylkArchitect(
                    path=sylk_json_path,
                    domain=SYLK_JSON.domain,
                    project_name=SYLK_JSON.project.get("name"),
                )
                if namespace[0] == "package":
                    generate.package(
                        results,
                        SYLK_JSON,
                        ARCHITECT,
                        args.expand,
                        args.verbose,
                        args.deps
                    )

                elif namespace[0] == "service":
                    generate.service(
                        results,
                        SYLK_JSON,
                        ARCHITECT,
                        args.expand,
                        args.verbose,
                        args.deps,
                        args.tag
                    )

                elif namespace[0] == "message":
                    generate.message(
                        results,
                        SYLK_JSON,
                        ARCHITECT,
                        args.expand,
                        args.verbose,
                        args.parent,
                        # generate_package_func=generate.package,
                        args.deps,
                        args.tag
                    )

                elif namespace[0] == "rpc":
                    generate.rpc(
                        results,
                        SYLK_JSON,
                        ARCHITECT,
                        parent=args.parent,
                        expand=args.expand,
                        deps=args.deps
                    )

                elif namespace[0] == "enum":
                    generate.enum(
                        results,
                        SYLK_JSON,
                        ARCHITECT,
                        parent=args.parent,
                        generate_package_func=generate.package,
                        tag=args.tag
                    )

                if args.build:
                    build.build_all(sylk_json_path)

            elif hasattr(args, "source") and hasattr(args, "target"):
                """Package command process"""

                if args.remove:
                    pack.remove_import(
                        args.source, args.target, sylk_json_path, SYLK_JSON
                    )
                else:
                    pack.import_package(
                        args.source, args.target, sylk_json_path, SYLK_JSON
                    )

            elif args.undo:
                """Undo command process"""

                path = sylk_json_path.replace("sylk.json", ".sylk/cache")

                cache_files = file_system.walkFiles(path)
                cache_files.sort()
                last_save = cache_files[
                    len(cache_files) - 2 if len(cache_files) > 1 else 1
                ]
                print_note(
                    {"cache": cache_files, "action": "undo", "active": last_save},
                    pprint=True,
                )

                # ARCHITECT = SylkArchitect(
                # path=sylk_json_path,save=last_save)
                # ARCHITECT.Save(undo_save=True)
            elif args.redo:
                """Redo command process"""

                path = sylk_json_path.replace("sylk.json", ".sylk/cache")

                cache_files = file_system.walkFiles(path)
                cache_files.sort(reverse=True)
                # logging.error(cache_files)
                # ARCHITECT = SylkArchitect(
                #     path=sylk_json_path,save=cache_files[len(cache_files)-2 if len(cache_files) > 1 else 1])
                # ARCHITECT.Save()
            elif hasattr(args, "protos") and hasattr(args, "code"):
                """Build command process"""

                if args.code:
                    print_info("🔨 Building project resources code files")
                    build.build_code(sylk_json_path)
                elif args.protos:
                    print_info("🔨 Building project resources proto's files")
                    build.build_protos(sylk_json_path)
                elif args.code == False and args.protos == False:
                    print_info("🔨 Building project resources")
                    build.build_all(sylk_json_path)

            elif args.purge:
                """Purge command process"""

                temp_path = sylk_json_path.replace("sylk.json", ".sylk/context.json")
                confirm_purge = prompter.QConfirm(
                    name="confirm",
                    message="You are about to purge the sylk context are you sure?",
                    default=False,
                )
                confirm = prompter.ask_user_question(questions=[confirm_purge])
                if confirm.get("confirm"):
                    file_system.removeFile(temp_path)
                    print_success("Purged sylk context !")
                else:
                    print_warning("Cancelling purge for sylk context")
            elif hasattr(args, "log_level") and hasattr(args, "rpc") == False:
                """Run command process"""

                run.run_server(SYLK_JSON, args.log_level)

            elif hasattr(args, "name") and hasattr(args, "extension") == False:
                """Edit command process"""

                resource = parse_name_to_resource(args.name, SYLK_JSON)
                type = resource.get("type")
                ARCHITECT = SylkArchitect(
                    path=sylk_json_path,
                    domain=SYLK_JSON.domain,
                    project_name=SYLK_JSON.project.get("name"),
                )
                print(type)

                if type == "packages":
                    edit.edit_package(resource, args.action, SYLK_JSON, ARCHITECT)
                elif type == "service":
                    edit.edit_service(resource, args.action, SYLK_JSON, ARCHITECT)
                elif type == "descriptor":
                    kind = resource.get("kind")
                    if kind == resources.ResourceKinds.enum.value:
                        edit.edit_enum(
                            resource,
                            action=args.action,
                            sub_actions=args.sub_actions,
                            sylk_json=SYLK_JSON,
                            architect=ARCHITECT,
                            expand=args.expand,
                        )
                    elif kind == resources.ResourceKinds.enum_value.value:
                        edit.edit_enum_value(
                            resource, args.action, SYLK_JSON, ARCHITECT
                        )
                    elif kind == resources.ResourceKinds.field.value:
                        edit.edit_field(
                            resource,
                            action=args.action,
                            sub_actions=args.sub_actions,
                            sylk_json=SYLK_JSON,
                            architect=ARCHITECT,
                            expand=args.expand,
                        )
                    elif kind == resources.ResourceKinds.message.value:
                        edit.edit_message(
                            resource=resource,
                            action=args.action,
                            sub_actions=args.sub_actions,
                            sylk_json=SYLK_JSON,
                            architect=ARCHITECT,
                            expand=args.expand,
                        )
                    elif kind == resources.ResourceKinds.method.value:
                        edit.edit_rpc(
                            resource=resource,
                            action=args.action,
                            sub_actions=args.sub_actions,
                            sylk_json=SYLK_JSON,
                            architect=ARCHITECT,
                            expand=args.expand,
                        )

            elif hasattr(args, "name") and hasattr(args, "extension"):
                """Extend command process"""

                resource = parse_name_to_resource(args.name, SYLK_JSON)
                extend.extend_resource(resource, args.extension, SYLK_JSON)

            elif hasattr(args, "path"):
                """Template command process"""
                ARCHITECT = SylkArchitect(
                    path=sylk_json_path,
                    domain=SYLK_JSON.domain,
                    project_name=SYLK_JSON.project.get("name"),
                )
                template_commands(args, SYLK_JSON, ARCHITECT)

            elif hasattr(args, "service") and hasattr(args, "rpc"):
                """Call command process"""
                print_note(f"Calling {args.service}->{args.rpc}")
                call.CallRPC(
                    args.service,
                    args.rpc,
                    SYLK_JSON,
                    host=args.host,
                    port=args.port,
                    debug=args.debug,
                    timeout=int(args.timeout),
                )

            elif hasattr(args, "edit"):
                """Config command"""
                if args.edit:
                    print_warning(
                        "Not supporting editing of sylk.build configurations through the CLI yet..."
                    )
                if args.token:
                    config_command.refresh_global_token()
                else:
                    config_command.display_configs(SYLK_JSON.path, dictionary=args.dict)
            else:
                # List command execution
                if hasattr(args, "full_name"):
                    if args.full_name is None:
                        if args.dependencies == True:
                            ls.list_dependencies(args.type, SYLK_JSON)
                        elif args.cloud:
                            sylk_project_config = prj_conf.parse_project_config(
                                os.getcwd()
                            )
                            print_info(f"Listing all projects")
                            sylkCloud = cloud.SylkCloud(
                                sylk_project_config.get("token"), None, None
                            )
                            cloud_projects = []
                            for prj in sylkCloud.listProjects():
                                cloud_projects.append(prj)

                            ls.list_projects(sylkCloud._org_id, cloud_projects)
                        # List templates execution
                        elif args.templates:
                            sylk_project_config = prj_conf.parse_project_config(
                                os.getcwd()
                            )
                            ls.list_templates(sylk_project_config, SYLK_JSON)
                            # ls.list_cloud_projects(args.full_name,SYLK_JSON)
                        elif hasattr(args, "type"):
                            ls.list_by_resource(args.type, SYLK_JSON)
                    else:
                        ls.list_by_name(args.full_name, SYLK_JSON)
                else:
                    if hasattr(args, "protos"):
                        print_warning("Cant migrate existing sylk.build project !")
                        exit(1)
                        # Logging version
                    if args.version:
                        print_version(__version__.__version__)
                        exit(0)
                    parser.print_help()

        else:
            # Global sylk cli commands
            # sylk_project_config = prj_conf.parse_project_config(os.getcwd())
            # print_note(sylk_project_config,True)
            if hasattr(args, "protos") and hasattr(args, "server_language"):
                """Migrations commands"""
                migrate.migrate_project(
                    args.protos,
                    output_path=file_system.get_current_location(),
                    format="json",
                    server_language=args.server_language,
                    clients=args.clients,
                )
            elif hasattr(args, "path"):
                """Templates command"""
                template_commands(args)
            elif hasattr(args, "organization"):
                """Cloud commands - login"""
                sylk_project_config = prj_conf.parse_project_config(os.getcwd())
                # print_note(sylk_project_config,True)
                print_info(f'Logging into "{args.organization}"')
                cloud.SylkCloud(
                    sylk_project_config.get("token"), args.organization, None
                )
                print_success(f'Logged into: "{args.organization}"')
            if args.command == "ls":
                if args.cloud:
                    """Cloud commands - list projects"""
                    sylk_project_config = prj_conf.parse_project_config(os.getcwd())
                    print_info(f"Listing cloud projects")
                    sylkCloud = cloud.SylkCloud(
                        sylk_project_config.get("token"), None, None
                    )
                    cloud_projects = []
                    for prj in sylkCloud.listProjects():
                        cloud_projects.append(prj)

                    ls.list_projects(sylkCloud._org_id, cloud_projects)
                elif args.templates:
                    """Templates commands - list templates"""
                    sylk_project_config = prj_conf.parse_project_config(os.getcwd())
                    print_info(f"Listing sylk templates")

                    ls.list_templates(sylk_project_config, None)
            elif hasattr(args, "edit"):
                """Configs commands"""
                if args.token is not None:
                    # print(args.token)
                    config_command.refresh_global_token()
            elif args.version:
                print_version(__version__.__version__)
            else:
                print_warning(
                    "Not under valid sylk.build project !\n\tMake sure you are on the root directory of your project"
                )
                parser.print_help()


def parse_name_to_resource(full_name, sylk_json: helpers.SylkJson):
    resource = None
    try:
        resource = sylk_json.get_package(full_name)
        if resource is not None:
                return resource
    except:
        resource = sylk_json.get_service(full_name)
        if resource is not None:
            return resource
        resource = sylk_json.get_enum(full_name)
        if resource is not None:
            return resource
        resource = sylk_json.get_message(full_name)
        if resource is not None:
            return resource

    print_error(
        f"Can not find any resource by the name -> {full_name}\n\t-> Try running: $ sylk ls"
    )
    exit(1)


def parse_namespace_resource(name, path: str, sylk_json: helpers.SylkJson):
    path = path.replace('.','/')
    questions = []
    namespace = name[0]
    # if namespace == 's':
    #     namespace = 'service'
    #     questions = sylk_g_s_q
    if namespace == "p":
        namespace = "package"
        # questions = sylk_g_p_q
    elif namespace == "r":
        namespace = "rpc"
        services = sylk_json.services
        temp_s = []
        parent = None
        if services is None or len(services) == 0:
            print_error(
                "No listed services in sylk.json file\n\tCreate a new service first then return to create a 'message'"
            )
            exit(1)

        for svc in services:
            temp_s.append(
                (
                    "{} [{}]".format(svc["name"], svc["fullName"]),
                    svc["fullName"],
                )
            )
        if len(path.split('/'))>1:
            parent = '.'.join(path.replace('/','.').split('.')[:-1])
        has_service = False
        if parent is not None:
            for s in temp_s:
                if parent in s[0]:
                    parent = s[1]
                    has_service = True

            if has_service == False:
                print_error(
                    f"Service -> {parent} not exists under {sylk_json.project.get('name')}"
                )
                exit(1)
        sylk_g_r_q = [
            prompter.QText(name="rpc", message="Enter rpc name", validate=validation),
            prompter.QList(
                name="type",
                message="Choose message type",
                choices=[
                    ("Unary", (False, False)),
                    ("Client stream", (True, False)),
                    ("Server stream", (False, True)),
                    ("Bidi stream", (True, True)),
                ],
            ),
        ]

        if has_service == False:
            sylk_g_r_q.append(
                prompter.QList(
                    "service",
                    message="Choose a service to attach the rpc",
                    choices=temp_s,
                )
            )
        questions = sylk_g_r_q

    elif namespace == "m":
        namespace = "message"
        packages = sylk_json.packages
        temp_p = []
        parent = None
        if packages is None or len(packages) == 0:
            print_error(
                "No listed packages in sylk.json file\n\tCreate a new package first then return to create a 'message'"
            )
            exit(1)
        if packages is not None and len(packages) != 0:
            for pkg in packages:
                temp_p.append(
                    (
                        "{0} [{1}]".format(
                            packages[pkg]["name"], packages[pkg]["package"]
                        ),
                        packages[pkg]["package"],
                    )
                )
        if len(path.split('/'))>1:
            parent = '.'.join(path.replace('/','.').split('.')[:-1])
            
        has_package = False
        if parent is not None:
            for _,p in temp_p:
                if parent in p:
                    has_package = True
            if has_package == False:
                print_error(
                    f"Package -> {parent} not exists under {sylk_json.project.get('name')}"
                )
                exit(1)

        sylk_g_m_q = [
            prompter.QText(
                name="message", message="Enter message name", validate=validation
            ),
        ]

        if has_package == False:
            sylk_g_m_q.append(
                prompter.QList(
                    name="package",
                    message="Choose a package to attach the message",
                    choices=sorted(temp_p,key=lambda x: x[1]),
                )
            )

        questions = sylk_g_m_q

    elif namespace == "e":
        namespace = "enum"
        packages = sylk_json.packages
        services = sylk_json.services
        temp_p = []
        parent = None
        if (packages is None or len(packages) == 0) and (
            services is None or len(services) == 0
        ):
            print_error(
                "No listed packages and services in sylk.json file\n\tCreate a new package or service first then return to create a 'enum'"
            )
            exit(1)

        if packages is not None and len(packages) != 0:
            for pkg in packages:
                temp_p.append(
                    (
                        "{0} [{1}]".format(
                            packages[pkg]["name"], packages[pkg]["package"]
                        ),
                        packages[pkg]["package"],
                    )
                )
           
        if len(path.split('/'))>1:
            parent = '.'.join(path.replace('/','.').split('.')[:-1])
        has_parent = False
        if parent is not None:
            for p in temp_p:
                if p[1] == parent:
                    has_parent = True
            if has_parent == False:
                print_error(f"{parent} Is not under current project")
                exit(1)
        else:
            sylk_g_e_q.append(
                prompter.QList(
                    name="package", message="Choose a package", choices=temp_p
                )
            )

        questions = sylk_g_e_q

    elif namespace == "s":
        parent = '.'.join(path.replace('/','.').split('.')[:-1])
        namespace = "service"
        packages = sylk_json.packages
        services = sylk_json.services
        temp_p = []
        parent = None
        if packages is None or len(packages) == 0:
            print_error(
                "No listed packages in sylk.json file\n\tCreate a new package first then return to create a 'service'"
            )
            exit(1)

        if packages is not None and len(packages) != 0:
            for pkg in packages:
                temp_p.append(
                    (
                        "{0} [{1}]".format(
                            packages[pkg]["name"], packages[pkg]["package"]
                        ),
                        packages[pkg]["package"],
                    )
                )
        if len(path.split('/'))>1:
            parent = '.'.join(path.replace('/','.').split('.')[:-1])

        has_parent = False
        if parent is not None:
            for _,p in temp_p:
                if p == sylk_json.domain + '.' + parent:
                    has_parent = True
            if has_parent == False:
                print_error(
                    f"cannot create service inside '{parent}' is not found in current project"
                )
                exit(1)
        else:
            sylk_g_s_q.append(
                prompter.QList(
                    name="package",
                    message="Choose a package to host the service",
                    choices=temp_p,
                )
            )

        questions = sylk_g_s_q

    return namespace, questions


def template_commands(args, sylk_json: helpers.SylkJson = None, architect=None):
    try:
        if args.path == "list":
            prj_configs = prj_conf.parse_project_config(sylk_json.path)
            print_info(
                [
                    temp
                    for temp in prj_configs.get("sylk_templates")
                    if "Blank" not in temp
                ],
                True,
                "sylk Builtins",
            )
            if prj_configs is not None:
                print_note(
                    prj_configs.get("custom_templates"),
                    True,
                    "Custom Templates [config.py]",
                )
        else:
            if file_system.check_if_file_exists(args.path):
                if args.load:
                    template.load_template(args.path)
                else:
                    if "sylk.json" in args.path:
                        prj_configs = prj_conf.parse_sylk_config(
                            sylk_json.path, proto=True
                        )
                        # print(prj_configs)
                        SYLK_JSON = file_system.rFile(args.path, json=True)
                        SYLK_JSON = helpers.SylkJson(sylk_json=SYLK_JSON)
                        filename = (
                            SYLK_JSON.project.get("packageName")
                            if args.template_name is None
                            else args.template_name
                        )
                        save_file_location = (
                            args.path.replace(
                                "sylk.json", "{0}.template.py".format(filename)
                            )
                            if args.out_path is None
                            else file_system.join_path(
                                args.out_path, "{0}.template.py".format(filename)
                            )
                        )
                        if prj_configs.template is not None:
                            filename = (
                                filename
                                if prj_configs.template.name is None
                                else filename
                            )
                            save_file_location = (
                                save_file_location
                                if prj_configs.template.out_path is None
                                else file_system.join_path(
                                    SYLK_JSON.path.replace("sylk.json", ""),
                                    prj_configs.template.out_path,
                                    "{0}.template.py".format(filename),
                                )
                            )

                        parent_path = file_system.join_path(
                            file_system.get_current_location(),
                            os.path.dirname(save_file_location),
                        )
                        include_code = (
                            args.code
                            if prj_configs.template is None
                            else prj_configs.template.include_code
                            if prj_configs.template.include_code is not None
                            else False
                        )

                        if file_system.check_if_dir_exists(parent_path):
                            file_system.wFile(
                                save_file_location,
                                template.create_sylk_template_py(
                                    SYLK_JSON, include_code, prj_configs
                                ),
                                overwrite=True,
                            )
                            print_success(
                                "Generated project template for '{0}'\n\t-> {1}".format(
                                    SYLK_JSON.project.get("name"), save_file_location
                                )
                            )
                        else:
                            print_warning(
                                "Path to template output path does not exist ! [{0}] - Will try to create the sub-dir".format(
                                    save_file_location
                                )
                            )
                            file_system.wFile(
                                save_file_location,
                                template.create_sylk_template_py(
                                    SYLK_JSON, include_code, prj_configs
                                ),
                                overwrite=True,
                                force=True,
                            )
                            print_success(
                                "Generated project template for '{0}'\n\t-> {1}".format(
                                    SYLK_JSON.project.get("name"), save_file_location
                                )
                            )
                            exit(1)
                    # elif '.proto' in args.path:
                    #     parse = parser.sylkParser(path=args.path)
                    #     print(parse)
                    else:
                        if file_system.check_if_dir_exists(args.path):
                            # builder = sylkBuilder(path=file_system.get_current_location(),hooks=[sylkMigrate])
                            # builder.PreBuild()
                            # print_info(file_system.join_path(file_system.get_current_location(),args.path))
                            # builder.ParseProtosToResource(project_name="test",protos_dir=file_system.join_path(file_system.get_current_location(),args.path),clients=[],server_language="python")
                            # builder.PostBuild()
                            raise errors.SylkProtoError(
                                "Not supported yet",
                                "Will be used to pass a directory path which holds proto files",
                            )
                        else:
                            raise errors.SylkProtoError(
                                "Export Service Template Error",
                                "File type not supported",
                            )
            elif file_system.check_if_dir_exists(args.path):
                raise errors.SylkProtoError(
                    "Not supported yet",
                    "Will be used to pass a directory path which holds proto files",
                )
            else:
                # Handle custom template import / builtin template
                if "@" in args.path:
                    prj_configs = prj_conf.parse_project_config(sylk_json.path)
                    if args.path in config.configs.sylk_templates:
                        # Check if suffix of template name is Py
                        if (
                            "Py" == args.path[len(args.path) - 2 :]
                            and sylk_json.project.get("server").get("language")
                            != "python"
                        ):
                            raise errors.SylkValidationError(
                                "Not supporting server language",
                                "The [{0}] template is only supporting 'python' as server language please try and run - sylk template {1} --load".format(
                                    args.path, args.path.replace("Py", "Ts")
                                ),
                            )
                        # Check if suffix of template name is Ts
                        if (
                            "Ts" == args.path[len(args.path) - 2 :]
                            and sylk_json.project.get("server").get("language")
                            != "typescript"
                        ):
                            raise errors.SylkValidationError(
                                "Not supporting server language",
                                "The [{0}] template is only supporting 'typescript' as server language please try and run - sylk template {1} --load".format(
                                    args.path, args.path.replace("Ts", "Py")
                                ),
                            )
                        # Attach template from builtins
                        helpers.attach_template(architect, args.path)
                    else:
                        # Handle custom templates
                        if prj_configs is not None:
                            print_warning(
                                "Attaching custom templates. If you want to attach a builtin template drop the 'templates' array in config.py file."
                            )
                            if prj_configs.get("custom_templates"):
                                for temp in prj_configs.get("custom_templates"):
                                    template_path = file_system.join_path(
                                        file_system.get_current_location(), temp[1]
                                    )
                                    if temp[0] == args.path:
                                        if file_system.check_if_file_exists(
                                            template_path
                                        ):
                                            # Attach template from custom templates
                                            print_info(
                                                "Running template file for {0}".format(
                                                    args.path
                                                )
                                            )
                                            subprocess.run(
                                                [
                                                    "python",
                                                    template_path,
                                                    "--domain",
                                                    architect._domain,
                                                    "--project-name",
                                                    architect._project_name,
                                                ]
                                            )
                                        else:
                                            raise errors.SylkValidationError(
                                                "Template not found",
                                                "The template file is not found on : {0}".format(
                                                    template_path
                                                ),
                                            )
                                    else:
                                        raise errors.SylkValidationError(
                                            "Template not found",
                                            "Custom template [{0}] not listed on 'templates' array at config.py file.".format(
                                                args.path
                                            ),
                                        )
                            else:
                                raise errors.SylkValidationError(
                                    "Config templates are empty",
                                    "Please make sure you configurd a list of templates in your custom config.py file under root project directory",
                                )
                else:
                    raise errors.SylkProtoError(
                        "Export Service Template Error",
                        "Make sure you are passing a valid path to sylk.json / protos directory / sylk.template.py script for SylkArchitect - or a valid id for the template!",
                    )
    except Exception as e:
        print_error(
            e,
            True,
            e.__class__.__name__ + " : " + e.resource if hasattr(e, "resource") else "",
        )
